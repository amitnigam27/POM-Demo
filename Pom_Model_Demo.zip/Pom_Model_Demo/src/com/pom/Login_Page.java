package com.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login_Page {
	
	WebDriver driver;
	
	 public  Login_Page(WebDriver driver){

        this.driver = driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);

    }
	
	
	@FindBy(xpath="//td//input[@name='userName']")
	WebElement username;

	
	@FindBy(xpath="//td//input[@name='password']")
	WebElement password;
	
	@FindBy(xpath="//td//input[@name='login']")
	WebElement login;	
	
	
	public void login(String usrname, String pasword)
	{
		username.sendKeys(usrname);
		password.sendKeys(pasword);
		
		
		login.click();
		
	}
	
	
	
	
	
	
	
	
	
	
}
