package com.pom;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Book_Flight {

	int passCount;
	 WebDriver driver;
	Random ran=new Random();
	int a=4;
	
	public Book_Flight(WebDriver driver, int passCount){

        this.driver = driver;
        this.passCount=passCount;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);

    }
	
	@FindBy(xpath="//input[@name='creditnumber']")
	WebElement cardNumber;
	
	@FindBy(xpath="//input[@name='cc_frst_name']")
	WebElement cc_frst_name;
	
	@FindBy(xpath="//input[@name='cc_last_name']")
	WebElement cc_last_name;
	
	@FindBy(xpath="//input[@name='buyFlights']")
	WebElement buyFlights;
	
	public void booking()
	{
		
		for(int i=0;i<=passCount;i++)
		{
		 	driver.findElement(By.xpath("//input[@name='passFirst"+i+"']")).sendKeys("Passenger"+(i+1)+"FirstName");
		 	driver.findElement(By.xpath("//input[@name='passLast"+i+"']")).sendKeys("Passenger"+(i+1)+"LasttName");
		 	WebElement meal=driver.findElement(By.xpath("//select[@name='pass."+i+".meal']"));
		 	Select Meal= new Select(meal);
			Meal.selectByIndex(ran.nextInt(a+6));			
		}
		cardNumber.sendKeys("256314653541");
		cc_frst_name.sendKeys("Amit");
		cc_last_name.sendKeys("Nigam");
		
		buyFlights.click();
	}
	
}
