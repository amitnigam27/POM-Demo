package com.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LogOut {
	 WebDriver driver;
	public LogOut(WebDriver driver){

        this.driver = driver;
        
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);

    }
	
	@FindBy(xpath="//a//img[@src='/images/forms/Logout.gif']")
	WebElement logout;
	
	public void logOut()
	{
		logout.click();
	}
	
}
