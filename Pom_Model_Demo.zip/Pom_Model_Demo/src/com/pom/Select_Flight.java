package com.pom;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Select_Flight {
	WebDriver driver;
	
	Random ran=new Random();
	
	public  Select_Flight(WebDriver driver){

        this.driver = driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);

    }
	
	@FindBy(xpath="(//tr//input[@name='outFlight'])")
	List<WebElement> departFlight;
	
	
	@FindBy(xpath="(//tr//input[@name='inFlight'])")
	List<WebElement> returnFlight;
	
	@FindBy(xpath="//p//input[@name='reserveFlights']")
	WebElement reserveContinue;
	
	public void selectFlight() {
	
	this.departFlight.get(ran.nextInt(this.departFlight.size())).click();
	
	
	this.returnFlight.get(ran.nextInt(this.returnFlight.size())).click();
	
	reserveContinue.click();
	
	
	}
}
