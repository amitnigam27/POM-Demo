package com.pom;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Find_Flights {
	WebDriver driver;
	int a=4;
	Random ran=new Random();
	
	public Find_Flights(WebDriver driver){

        this.driver = driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);

    }
	
	@FindBy(xpath="(//b/font/input[@name='tripType'])")
	List<WebElement> type;
	
	@FindBy(xpath="(//td/b/select[@name='passCount'])")
	WebElement passengers;
	
	@FindBy(xpath="(//td/select[@name='fromPort'])")
	WebElement depart;
	
	@FindBy(xpath="(//td//select[@name='fromMonth'])")
	WebElement fromMonth;
	
	@FindBy(xpath="(//td//select[@name='fromDay'])")
	WebElement fromDay;
	
	@FindBy(xpath="(//td//select[@name='toPort'])")
	WebElement arrive;
	
	@FindBy(xpath="(//td//select[@name='toMonth'])")
	WebElement returnMonth;
	
	@FindBy(xpath="(//td//select[@name='toDay'])")
	WebElement returnDay;
	
	@FindBy(xpath="(//td//input[@name='servClass'])")
	List<WebElement> serviceClass;
	
	@FindBy(xpath="(//td//select[@name='airline'])")
	WebElement airline;
	
	@FindBy(xpath="//td//input[@name='findFlights']")
	WebElement Continue;
	
	public int flights()
	{		
		this.type.get(ran.nextInt(this.type.size())).click();
		
		
		int passCount=ran.nextInt(a);
		Select PassCount= new Select(passengers);
		PassCount.selectByIndex(passCount);
		
		
	
		Select Depart= new Select(depart);
		Depart.selectByIndex(ran.nextInt(a+6));
		
			
		Select FromMonth= new Select(fromMonth);	
		FromMonth.selectByIndex(ran.nextInt(a+8));
		
		
		Select Fromday= new Select(fromDay);
		Fromday.selectByIndex(ran.nextInt(a+27));
		
		
		Select Arrive= new Select(arrive);	
		Arrive.selectByIndex(ran.nextInt(a+6));
		
		
		Select ReturnMonth= new Select(returnMonth);
		ReturnMonth.selectByIndex(ran.nextInt(a+8));
		
		
		Select Returnday= new Select(returnDay);
		Returnday.selectByIndex(ran.nextInt(a+27));
		
		
		this.serviceClass.get(ran.nextInt(this.serviceClass.size())).click();

		Select Airline= new Select(airline);
		Airline.selectByIndex(ran.nextInt(a));
		
		
		Continue.click();
		return passCount;
		
	}
	
	
}
