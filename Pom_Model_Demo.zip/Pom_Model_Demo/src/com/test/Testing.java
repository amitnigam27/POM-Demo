package com.test;

import org.testng.annotations.Test;

import com.pom.Book_Flight;
import com.pom.Find_Flights;
import com.pom.LogOut;
import com.pom.Login_Page;
import com.pom.Select_Flight;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

public class Testing {
	private static WebDriver driver;
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\ANigam\\eclipse-workspace\\Selenium_Demo\\resource\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.navigate().to("http://newtours.demoaut.com");
		driver.manage().window().maximize();
  }

  
  @Test
  public void f() {
	  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  Login_Page log=new Login_Page(driver);
	  log.login("readonly", "readonly");
	  
	  Find_Flights flight=new Find_Flights(driver);
	  int passcount=flight.flights();
	  
	  
	  Select_Flight select=new Select_Flight(driver);
	  select.selectFlight();
	  
	  Book_Flight book=new Book_Flight(driver, passcount);
	  book.booking();
	  
	  LogOut logout=new LogOut(driver);
	  logout.logOut();
	  
	  driver.quit();
  }
}
