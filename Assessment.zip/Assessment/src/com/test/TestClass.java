package com.test;

import org.testng.annotations.Test;

import com.pom.Login;
import com.pom.Mail_Page;
import com.pom.Validate;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class TestClass {
  WebDriver driver;
  @BeforeTest
  public void beforeTest() {
	  
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\ANigam\\Desktop\\resource\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("https://mail.prolifics.com/owa/");
		driver.manage().window().maximize();
  }
  
  @Test
  public void func() throws InterruptedException, IOException {
	  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  
	  FileInputStream fis=new FileInputStream("C:\\Users\\ANigam\\Desktop\\Details.xlsx");
	  XSSFWorkbook wb=new XSSFWorkbook(fis);
	  XSSFSheet sheet = wb.getSheet("Amit");
	  Row row = sheet.getRow(0);
	  Cell cell_0 = row.getCell(0);
	  Cell cell_1 = row.getCell(1);
	  
	  
	  String cells = cell_0.getStringCellValue();
	  String cells1 = cell_1.getStringCellValue();
	System.out.println(cells1);
	  
	  
	  
	  Login log=new Login(driver);
	  log.signin(cells, cells1);
	  
	  Mail_Page mail=new Mail_Page(driver);
	  mail.sendMail();
	 
	  Validate val=new Validate(driver);
	  val.validate();
	  Thread.sleep(5000);
	  wb.close();
	  
	  //driver.close();
  }

}
