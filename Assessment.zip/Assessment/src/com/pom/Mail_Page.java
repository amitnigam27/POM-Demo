package com.pom;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Mail_Page {
	
	WebDriver driver;
	
	public  Mail_Page(WebDriver driver){

        this.driver = driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);

    }
	
	@FindBy(xpath="//button[@class=\"_n_g2 o365button ms-font-m\"]")
	WebElement newmail;
	
	@FindBy(xpath="(//div[@class=\"_fp_u\"]//input)[1]")
	WebElement to;
	
	@FindBy(xpath="//div[@class=\"_mcp_O1\"]/input")
	WebElement sub;
	
	@FindBy(xpath="//iframe[@id=\"EditorBody\"]")
	WebElement fr1;
	
	@FindBy(xpath="//div[@id='MicrosoftOWAEditorRegion']/p[2]")
	WebElement msgBody;
	
	@FindBy(xpath="//div[@class=\"_mcp_M1\"]//button[@autoid=\"_mcp_6\"]")
	WebElement send;
	
	
	public void sendMail() throws InterruptedException, IOException
	{
		WebDriverWait wait=new WebDriverWait(driver, 15);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.visibilityOf(newmail));
		newmail.click();
		
		wait.until(ExpectedConditions.visibilityOf(to));
		to.click();
		
		FileInputStream fis=new FileInputStream("C:\\Users\\ANigam\\Desktop\\Details.xlsx");
		  XSSFWorkbook wb=new XSSFWorkbook(fis);
		  XSSFSheet sheet = wb.getSheet("Amit");
		  Row row = sheet.getRow(0);
		  Cell cell_2 = row.getCell(2);
		  Cell cell_3 = row.getCell(3);
		  
		  String cells2 = cell_2.getStringCellValue();
		  String cells3 = cell_3.getStringCellValue();
		  
		  
		
		to.sendKeys(cells2);
		
		sub.sendKeys(cells3);
		
		driver.switchTo().frame(fr1);
		System.out.println("********We are switch to the iframe*******");
		
		wait.until(ExpectedConditions.visibilityOf(msgBody));
		msgBody.click();
		
		System.out.println("clicked msg body");
		//Thread.sleep(5000);
		
//		String abc="This is just a demo for testing purpose";
//		msgBody.sendKeys(abc);
		
		driver.switchTo().defaultContent();
		System.out.println("********We are switch to the default content*******");
		
		send.click();
		wb.close();
		driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
		
	
	}
}
