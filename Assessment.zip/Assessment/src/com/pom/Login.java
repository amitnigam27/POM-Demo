package com.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	
	WebDriver driver;
	
	 public Login(WebDriver driver){

       this.driver = driver;
       //This initElements method will create all WebElements
       PageFactory.initElements(driver, this);

   }
		

		@FindBy(xpath="//input[@name='username']")
		WebElement username;
		
		@FindBy(xpath="//input[@name=\"password\"]")
		WebElement password;
		
		@FindBy(xpath="//div[@class=\"signinbutton\"]//span[@class=\"signinTxt\"]")
		WebElement signin;
		
		
		public void signin(String usrname, String pasword)
		{
			username.sendKeys(usrname);
			password.sendKeys(pasword);
			
			
			signin.click();
			
		}
	

}
